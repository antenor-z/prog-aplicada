#!/bin/sh

pandoc -o descricao.pdf descricao.md
pandoc -o descricao.docx descricao.md